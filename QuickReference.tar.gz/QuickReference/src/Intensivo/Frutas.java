/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Intensivo;

/**
 *
 * @author curso1
 */
public class Frutas {
    
    
    private String color;
    private String nombre;

    public Frutas() {
    }

    public Frutas(String color, String nombre) {
        this.color = color;
        this.nombre = nombre;
    }
    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
