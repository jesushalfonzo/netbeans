/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Intensivo;

/**
 *
 * @author curso1
 */
public class Pera extends Frutas{

    public Pera() {
        
    }
    
    
    
}
