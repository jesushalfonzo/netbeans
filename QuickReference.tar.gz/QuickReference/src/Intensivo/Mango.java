/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Intensivo;

/**
 *
 * @author curso1
 */
public class Mango extends Frutas {

    public Mango(String color, String nombre) {
        super(color, nombre);
    }
}
