/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package repaso;

/**
 *
 * @author curso4
 */
public class Repaso01 {
   
    public void metodo1(){
        
    }
    
    public void metodo2(int entero , String ss){
        
    }
    
    public int metodo3(int a, int b){
        return a + b;
    }
}
