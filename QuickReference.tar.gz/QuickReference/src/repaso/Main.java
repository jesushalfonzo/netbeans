/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package repaso;

//import static repaso.Repaso.Metodo2;

/**
 *
 * @author curso4
 */
public class Main {

    public static void main(String[] p) {
//        Metodo2();
        
        Repaso00 repaso = new Repaso00();
        repaso.metodo1();
//        System.out.println(repaso.met3());
        
    }
    
    
}
