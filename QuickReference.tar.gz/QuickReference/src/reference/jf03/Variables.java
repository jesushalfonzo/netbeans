/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reference.jf03;

/**
 *
 * @author curso1
 */
public class Variables {
    /*
    Variable de Clase, dado que se crea solo una sola.
    */
    public static String variableDeClase;
    /*
    Variable de instancia porque se crea una cada vez que se instancia un objeto
    de la clase.
    */
    public int variableDeInstancia;
    
    public void metodoEjemplo(int parametro){
        String variableLocal="Hola";
    }
}
