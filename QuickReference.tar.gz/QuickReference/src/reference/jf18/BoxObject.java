/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reference.jf18;

/**
 *
 * @author curso1
 */
public class BoxObject {

    private Object object;

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }
}
