/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reference.jf19;

/**
 *
 * @author curso1
 */
public class QR_Constants {
    public static final int _Lunes = 0;
    public static final int _Martes = 1;
    public static final int _Miercoles = 2;
    public static final int _Jueves = 3;
    public static final int _Viernes = 4;
    public static final int _Sabado = 5;
    public static final int _Domingo = 6;    
}
