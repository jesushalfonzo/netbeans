/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reference.jf01.class_anonymous;

/**
 *
 * @author yecheverria
 */
public class Rectangulo implements FigurasGeometricasInterface{

    @Override
    public float calcularArea() {
        return 3*5;
    }

    @Override
    public void dibujame() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
