/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reference.jf01;

/**
 *
 * @author curso1
 */
public interface InterfaceAnonima {

    void metodo1();

    void metodo2();

    void metodo3();

    String metodo4(String name);
}
