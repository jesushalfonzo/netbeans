/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reference.jf02;

/**
 *
 * @author yecheverria
 */
public abstract class Animales {

    public abstract void metodoPublico();

    private void metodoPrivado() {

    }

    protected abstract  void metodoProtected();

    abstract  void metodoPackage();
}
