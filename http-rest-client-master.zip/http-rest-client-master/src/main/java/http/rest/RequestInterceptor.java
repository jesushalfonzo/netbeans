package http.rest;

import org.apache.http.client.methods.HttpRequestBase;

public class RequestInterceptor {

    public void intercept(HttpRequestBase request) {
    }

}
